class Conv(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv : __torch__.torch.nn.modules.conv.___torch_mangle_85.Conv2d
  act : __torch__.torch.nn.modules.activation.___torch_mangle_86.SiLU
  def forward(self: __torch__.ultralytics.nn.modules.conv.___torch_mangle_87.Conv,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_202.SiLU,
    input: Tensor) -> Tensor:
    conv = self.conv
    _0 = (argument_1).forward25((conv).forward(input, ), )
    return _0
