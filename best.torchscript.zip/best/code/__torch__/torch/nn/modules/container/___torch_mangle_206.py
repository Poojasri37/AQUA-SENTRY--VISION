class ModuleList(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  __annotations__["0"] = __torch__.torch.nn.modules.container.___torch_mangle_189.Sequential
  __annotations__["1"] = __torch__.torch.nn.modules.container.___torch_mangle_197.Sequential
  __annotations__["2"] = __torch__.torch.nn.modules.container.___torch_mangle_205.Sequential
